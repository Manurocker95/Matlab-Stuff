%% Ejercicio 1:
f = @(y,t) y-t.^2+1;
a=0;
b=1;
h=0.2;
y0=0.5;
t= a:h:b;

y_s = Euler(f,t,y0)

yexacta = (t+1).^2 - 0.5.*exp(t)

hold on;
plot(t,y_s,'-mo')
plot(t,yexacta,'-ro')
hold off;

error=abs(y_s-yexacta).*100./yexacta

%% Comparando Operaciones con Varios Pasos de Discretizaci�n
f = @(y,t) y-t.^2+1;
a=0;
b=1;
y0=0.5;


hs=[0.2 0.1 0.05 0.01 0.001];

hold on;
for i=1:size(hs,2)
    h = hs(i)
    t = a:h:b;
    y_s = Euler(f,t,y0);
    yexacta = (t+1).^2 - 0.5.*exp(t);
    error=abs(y_s-yexacta);%./yexacta
    errorPorCien=abs(y_s-yexacta).*100./yexacta;
    
%     figure(i);
%     
%     plot(t,y_s,'-mo')
%     plot(t,yexacta,'-ro')
    plot(t,error)
end
hold off;


%% Ejercicio 2:

M=7;
B=50;
k=200;

f = @(u,v)[v; (-B/M)*abs(v)*v-(k/M)*u];
a=0;
b=0.2;
h=0.05;
y0=[0; 1];
t = a:h:b;

Y = EulerVectorial(f,t,y0)

hold on;
plot(t,Y(1,:))
plot(t,Y(2,:))
hold off;
