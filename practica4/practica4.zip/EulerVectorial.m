function [ y_s ] = EulerVectorial( f, intervalo , y0 )
%UNTITLED3 Summary of this function goes here
%   f: @(u,v) = [f_1 = @(u,v),
%                f_2 = @(u,v)]
%   a,b: intervalo
%   h: paso de discretizacion
%   y0: vector con valores iniciales

% Calculamos paso de discretizacion a partir de los valores
h = intervalo(2) - intervalo(1);

y_s = zeros(2,size(intervalo,2));
%Valor Inicial
y_s(:,1)= y0;
%Calculamos los siguientes valores
for i =1:size(intervalo,2)-1
    u = y_s(1,i);
    v = y_s(2,i);
    y_s(:,i+1)=y_s(:,i) + h.*f(u,v);
end 


end

